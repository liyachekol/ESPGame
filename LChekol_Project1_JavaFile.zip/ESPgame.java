/*
 * Class: CMSC203
 * Instructor:
 * Description: ESP: Gussing colors game
 * Due: 06/17/2025
 * Platform/compiler: Eclipse IDE 
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any student.
 * Print your Name here: LIYA CHEKOL
 */





import java.util.Scanner;
import java.io.File;

public class ESPgame {
    public static void main(String[] args) throws Exception {
        Scanner input = new Scanner(System.in);

        System.out.println("Welcome to ESPgame!");
        System.out.println("Choose from the options below:");
        System.out.println("1 - Display first 16 colors");
        System.out.println("2 - Display first 10 colors");
        System.out.println("3 - Display first 5 colors");
        System.out.println("4 - Exit");
        System.out.print("Enter your option: ");

          int option = input.nextInt();
        input.nextLine();

    if (option < 1 || option > 4) {
            System.out.println("Invalid option. Exiting.");
            input.close();
            return;  }

     if (option == 4) {
            System.out.println("Exiting program...");
            System.out.println("Liya Chekol");
            System.out.println("CS Student");
           System.out.println("6/17/25");
            input.close();
           return; }

        int colors_Show = 0;
        if (option == 1) colors_Show = 16;
        else if (option == 2) colors_Show = 10;
        else colors_Show = 5;

        File file = new File("colors.txt");
        if (!file.exists()) {
            System.out.println("colors.txt not found.");
            input.close();
            return; }

        String[] colors = new String[colors_Show];
        Scanner fileScanner = new Scanner(file);
        int index = 0;
        while (fileScanner.hasNextLine() && index < colors_Show) {
            colors[index] = fileScanner.nextLine();
            index++; }
        fileScanner.close();

        System.out.println("\nColors:");
        for (int i = 0; i < index; i++) {
            System.out.println((i + 1) + ". " + colors[i]);
        }

        int rounds = 3;
        int correct_count = 0;

        for (int round = 1; round <= rounds; round++) {
            System.out.println("\nRound " + round);
            System.out.println("I'm thinking of one of the colors above.");
            System.out.print("Your guess: ");
            String guess = input.nextLine();

            String chosen_Color = colors[(round - 1) % index];

            if (guess.equalsIgnoreCase(chosen_Color)) {
                correct_count++;
            }

            System.out.println("I was thinking of: " + chosen_Color);
        }

        System.out.println("\nGame Over!");
        System.out.println("You got " + correct_count + " out of " + rounds + " correct.");
        System.out.println("\nLiya Chekol");
        System.out.println("CS Student");
        System.out.println("6/17/25");

        input.close(); }
}
